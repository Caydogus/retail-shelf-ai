﻿export default {}
